﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WeatherApp.Core.Providers;
using WeatherApp.Core.Providers.Interfaces;

namespace WeatherApp.Controllers
{
    public class WeatherController : Controller
    {
        private readonly IWeatherProvider _weatherProvider;
        public WeatherController()
        {
            this._weatherProvider = new WeatherProvider();
        }
        // GET: Waether
        public ActionResult Index()
        {
            var weatherResponse = this._weatherProvider.GetAsync().Result;
            return View(weatherResponse);
        }
    }
}