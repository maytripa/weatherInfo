﻿using WeatherApp.Core.RemoteLookup.Interface;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using WeatherApp.Core.ViewModels;

namespace WeatherApp.Core.RemoteLookup
{
    public class WeatherLookupsProviders : IWeatherLookupsProviders
    {
        private readonly string _endpoint;
        public WeatherLookupsProviders()
        {
            _endpoint = $"https://api.openweathermap.org/data/2.5/weather" + $"?q={0}&APPID={Constants.Constants.AppId}" + "&units=metric";
        }
        public async Task<WeatherResponse> Get(string location)
        {
            var endpoint = $"https://api.openweathermap.org/data/2.5/weather" + $"?q={location}&APPID={Constants.Constants.AppId}" + "&units=metric";
            var request = WebRequest.Create(endpoint) as HttpWebRequest;

            string response = "";
            using (var res = request.GetResponse() as HttpWebResponse)
            {
                var reader = new StreamReader(res.GetResponseStream());
                response = reader.ReadToEnd();
            }
            var mappedResponse = JsonConvert.DeserializeObject<WeatherResponse>(response);
            return mappedResponse;
        }
    }
}
