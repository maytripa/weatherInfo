﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeatherApp.Core.ViewModels;

namespace WeatherApp.Core.Providers.Interfaces
{
    public interface IWeatherProvider
    {
        Task<LocationWeather> GetAsync();
        Task<InternationalLocationsWeather> GetAllAsync();
    }
}
