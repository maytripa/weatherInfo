﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Threading.Tasks;
using System.Xml;
using WeatherApp.Core.Domain.Models;
using WeatherApp.Core.Helpers;
using WeatherApp.Core.Providers.Interfaces;
using WeatherApp.Core.RemoteLookup;
using WeatherApp.Core.RemoteLookup.Interface;
using WeatherApp.Core.ViewModels;

namespace WeatherApp.Core.Providers
{
    public class WeatherProvider : IWeatherProvider
    {
        private readonly IWeatherLookupsProviders _lookups;
        public WeatherProvider()
        {
            this._lookups = new WeatherLookupsProviders();
        }

        public async Task<InternationalLocationsWeather> GetAllAsync()
        {
            var response = new InternationalLocationsWeather();
            var tasks = new List<Task>();
            response.LocationsParis = await this._lookups.Get("Paris");
            response.LocationsNewYork = await this._lookups.Get("New York");
            response.LocationsSidney = await this._lookups.Get("Sidney");
            response.LocationsMoscow = await this._lookups.Get("Moscow");

            return response;
        }

        public async Task<LocationWeather> GetAsync()
        {
            var mappedResponse = new LocationWeather();
            var geoLocation = GeoLocationProvider.GetInfo();
            var weatherDetails = await this._lookups.Get(geoLocation.City); 
            var intLocationsInfo = await this.GetAllAsync();
            mappedResponse.Location = geoLocation;
            mappedResponse.Weather = weatherDetails;
            mappedResponse.InternationalLocationsInformation = intLocationsInfo;
            return mappedResponse;
        }        
    }
}
