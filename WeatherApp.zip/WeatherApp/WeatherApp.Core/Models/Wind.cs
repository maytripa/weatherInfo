﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherApp.Core.Models
{
    public class Wind
    {
        public double Speed { get; set; }
        public int Deg { get; set; }
    }
}
