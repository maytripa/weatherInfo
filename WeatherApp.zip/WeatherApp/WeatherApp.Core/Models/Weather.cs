﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherApp.Core.Models
{
    public class Weather
    {
        public int Id { get; set; }
        public string Main { get; set; }
        public string Description { get; set; }
        public string Icon { get; set; }
        public string Cssclass { get { return this.Set(Main); } }
        private string Set(string Name)
        {
            if (Name == "Clear")
                return "sunnyscr";
            if (Name == "Clouds")
                return "cloudyscr";
            if (Name == "Rainy")
                return "rainyscr";
            if (Name == "")
                return "clear";
            return "";
        }
    }
}