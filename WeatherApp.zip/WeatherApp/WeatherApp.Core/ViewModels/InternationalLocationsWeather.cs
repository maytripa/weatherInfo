﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherApp.Core.ViewModels
{
    public class InternationalLocationsWeather
    {
        public WeatherResponse LocationsParis { get; set; }

        public WeatherResponse LocationsNewYork { get; set; }

        public WeatherResponse LocationsSidney{ get; set; }

        public WeatherResponse LocationsMoscow{ get; set; }
    }
}
