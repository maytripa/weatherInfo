﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeatherApp.Core.Domain.Models;

namespace WeatherApp.Core.ViewModels
{
    public class LocationWeather
    {
        public IpInfo Location { get; set; }
        public WeatherResponse Weather { get; set; }
        public InternationalLocationsWeather InternationalLocationsInformation { get; set; }
    }
}
