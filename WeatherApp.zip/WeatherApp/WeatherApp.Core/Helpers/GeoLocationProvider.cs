﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using WeatherApp.Core.Domain.Models;

namespace WeatherApp.Core.Helpers
{
    public static  class GeoLocationProvider
    {
        public static  readonly string HostName;
        public static readonly IPHostEntry HostEntry;
        public static readonly List<IPAddress> IPLists;
        static GeoLocationProvider()
        {
            HostName = Dns.GetHostName();
            HostEntry= Dns.GetHostEntry(HostName);
            IPLists = HostEntry?.AddressList?.ToList();
        }
        public static IpInfo GetInfo()
        {
            IpInfo ipInfo = new IpInfo();
           
            try
            {
                var ipadress = new WebClient().DownloadString(Constants.Constants.BaseIPLookupURL + "ip");
                var response = new WebClient().DownloadString(Constants.Constants.BaseIPLookupURL + ipadress);
                ipInfo = JsonConvert.DeserializeObject<IpInfo>(response);
                var myRI1 = new RegionInfo(ipInfo.Country);
                ipInfo.Country = myRI1.EnglishName;
            }
            catch (Exception)
            {
                //log exception
                ipInfo.Country = null;
            }
            return ipInfo;
        }
    }
}
