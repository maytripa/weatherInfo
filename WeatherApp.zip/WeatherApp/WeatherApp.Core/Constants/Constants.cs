﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherApp.Core.Constants
{
    public static class Constants
    {
        public const string BaseURI = "https://api.openweathermap.org/";
        public const string AppId = "9420ce45c183922c3e094854a90fefbe";
        public const string BaseIPLookupURL = "http://ipinfo.io/";
    }
}
